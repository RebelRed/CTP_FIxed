
$(document).ready(function () {
	app.initialized()
		.then(function (_client) {
			window.client = _client;
			this.private_conversations = false;
			this.newest_flag = false;
			this.conver_attachments = new Array();
			this.isAttachement = false;
			this.attachmentValues = [];
			window.contactList = [];
			window.agentList = [];
			this.printWindow = function () {
				var winPrint = window.open();
				winPrint.document.write($('.print').html());
				setTimeout(function () { winPrint.document.close(); }, 500);
				winPrint.focus();
				$(winPrint.window).on('load', function () {
					winPrint.print();
					winPrint.close();
				});
			}
			this.appActivated = function (contactList, agentList) {
				client.iparams.get().then(
					function (data) {
						var ticket = getTicketDetails(data.ticket_details, data.ticket_fields, contactList, agentList);
						var requester = getRequesterDetails(data.contact_details, contactList, agentList);
						var company = getCompanyDetails(data.company_details, contactList, agentList);
						Promise.all([ticket, requester, company]).then(() => {
							printWindow();
						})
							.catch((e) => {
								notify(e);
							});
						$('.domain_name').html(data.domainName);
					})
					.catch((e) => {
						notify(e)
					});
			}
			this.getCompanyDetails = (company_details) => {
				return new Promise((resolve, reject) => {
					getClientData("company").then(data => {
						if ('id' in data.company) {
							var options = {
								method: 'get',
								url: '/api/v2/companies/' + data.company.id
							};
							Promise.all([requestApi(options), requestApi({
								url: '/api/v2/company_fields',
								method: 'get'
							})]).then(d => {
								var company_data = JSON.parse(d[0]),
									company_details_to_print = [],
									company_fields = JSON.parse(d[1]);
								_.each(company_data.custom_fields, (v, i) => {
									company_data[i] = v;
								});
								_.each(company_details, (v, i) => {
									if (v) {
										var label = getLabel(i, company_fields);
										var value = getContactValue(i, company_data, company_fields);
										if (Array.isArray(value)) {
											if (value.length !== 0) {
												value = value.join(', ');
												company_details_to_print.push({ label, value });
											}
										} else {
											company_details_to_print.push({ label, value });
										}
									}
								});

								if (company_details_to_print.length === 0) {
									$('#company_div').hide();
								}
								prepareFields(company_details_to_print, 'company_details');
								resolve('done');
							}).catch(reject);
						} else {
							$('#company_div').hide();
							resolve('done');
						}

					}).catch(reject);
				});
			};

			this.getClientData = function (a) {
				return new Promise(function (resolve, reject) {
					client.data.get(a).then(resolve, reject);
				});
			};
			this.getRequesterDetails = function (contact_details, contactList, agentList) {
				return new Promise(function (resolve, reject) {
					getClientData("contact").then(function (result) {
						let contact_api;
						if (result.contact.is_agent) {
							agentList.forEach(agent => {
								if (parseInt(agent.id) === parseInt(result.contact.id)) {
									contact_api = agent;
								}
							})
						} else {
							contactList.forEach(contact => {
								if (parseInt(contact.id) === parseInt(result.contact.id)) {
									contact_api = contact;
								}
							})
						}
						requestApi({
							url: '/api/v2/contact_fields',
							method: 'get'
						}).then(function (data) {
							var isoLangs = {
								"tr": "Turkish",
								"ar": "Arabic",
								"ca": "Catalan; Valencian",
								"zh": "Chinese",
								"cs": "Czech",
								"da": "Danish",
								"nl": "Dutch",
								"en": "English",
								"et": "Estonian",
								"fi": "Finnish",
								"fr": "French",
								"de": "German",
								"he": "Hebrew (modern)",
								"hu": "Hungarian",
								"id": "Indonesian",
								"it": "Italian",
								"ja": "Japanese",
								"ko": "Korean",
								"lv": "Latvian",
								"nb": "Norwegian Bokmål",
								"pl": "Polish",
								"pt-BR": "Portuguese",
								"ro": "Romanian, Moldavian, Moldovan",
								"ru": "Russian",
								"sk": "Slovak",
								"sl": "Slovene",
								"es": "Spanish; Castilian",
								"sv": "Swedish",
								"th": "Thai",
								"uk": "Ukrainian",
								"vi": "Vietnamese",
								"pt-PT": "Portugese/Portugal",
								"es-LA": "Spanish (Latin America)",
								"zh-TW": "Chinese (Traditional)"
							}
							var contact = result.contact.is_agent ? contact_api.contact : contact_api, contact_details_to_print = [], contact_fields = JSON.parse(data);
							console.log("contact",contact);
							for (let key in contact.custom_fields) {
								const custom_field = contact.custom_fields[key];
								contact[key] = custom_field;
							}
							var company_id = contact.company_id;
							_.each(contact_details, function (value, index) {
								if (index === 'language') {
									contact_details_to_print.push({

										label: getLabel(index, contact_fields),
										value: isoLangs[contact.language]
									});
								} else if (index === 'tag_names' && (result.contact.tags.length)) {
									contact_details_to_print.push({
										label: getLabel(index, contact_fields),
										value: result.contact.tags
									});
								} else if (index === 'company_name') {
									requestApi({
										url: '/api/v2/companies/' + company_id,
										method: 'get'
									}).then(function (res) {
										res = JSON.parse(res).name;
										if (contact_details_to_print.length === 0) {
											$('#contact_div').hide();
										}
										contact_details_to_print.push({
											label: getLabel(index, contact_fields),
											value: res
										});;
										prepareFields(contact_details_to_print, 'contact_details');
										resolve('done');
									}).catch((e) => {
										notify(e)
									});

								} else {
									var val = getContactValue(index, contact, contact_fields);
									if (val !== null) {
										contact_details_to_print.push({
											label: getLabel(index, contact_fields),
											value: val
										});
									}
								}
							});
							if (contact_details_to_print.length === 0) {
								$('#contact_div').hide();
							}
							prepareFields(contact_details_to_print, 'contact_details');
							resolve('done');
						}).catch(reject);
					}).catch(reject);
				});
			};
			this.requestApi = function (options) {
				return new Promise((resolve, reject) => {
					var opt = {
						headers: {
							"Authorization": "Basic <%= encode(iparam.apiKey) %>",
							"Content-Type": "application/json; charset=utf-8"
						}
					};
					if ('body' in options) {
						opt['body'] = JSON.stringify(options.body);
					}
					var url = 'https://<%= iparam.domainName %>' + options.url;
					client.request[options.method](url, opt).then(function (data) {
						resolve(data.response);
					}).catch(reject);
				});
			};
			this.getTicketDetails = function (ticket_details, ticket_fields, contactList, agentList) {
				return new Promise((resolve, reject) => {
					Promise.all([getClientData('ticket')]).then(data => {
						var ticket = data[0].ticket;
						$('.ticket-number').html('#' + ticket.id);
						$('.ticket_source').html(ticket.source_type);
						var created_at = new Date(ticket.created_at).toDateString() + ' ' + new Date(ticket.created_at).toLocaleTimeString();
						$('.created_at').html(created_at);
						var ticket_details_to_print = [];
						var conversation_details_to_print = new Array();
						_.each(ticket_details, function (value, index) {
							if (value) {
								switch (index) {
									case 'subject':
										var subject = ticket.subject
										if (subject == '' || null) {
											$('.ticket_subject').hide();
										} else {
											$('.ticket_subject').html('<b>Subject</b><br>' + subject + '<br>');
										}
										break;
									case 'type':
									case 'status':
									case 'source':
									case 'priority':
										ticket_details_to_print.push({
											label: getLabel(index, ticket_fields),
											value: getValue(index, ticket, ticket_fields)
										});
										break;
									case 'tags':
										ticket_details_to_print.push({
											label: 'Tags',
											value: getValue(index, ticket, ticket_fields)
										});
										break;
									case 'agent':
										ticket_details_to_print.push({
											label: 'Agent',
											value: ticket.responder_id
										});
										break;
									case 'product':
										if (ticket.product_id !== null) {
											ticket_details_to_print.push({
												label: 'Product',
												value: ticket.product_id
											});
										}

										break;
									case 'description':
										var description = ticket.description;
										var description_text = ticket.description_text;
										if (description_text === `` || null) {
											$('.ticket_description').hide();
										}
										else {
											$('.ticket_description').html('<b>Description</b><br>' + description);
										}
										break;
									case 'private_conversations':
										private_conversations = true;
										break;
									case 'attachment':
										isAttachement = true;
										var attach = new Array();
										var values = new Array();
										attach = ticket.attachments;

										for (var i = 0; i < attach.length; i++) {

											values.push(attach[i].name);

										}
										conversation_flag = true;
										if (conversation_flag == true) {
											setConverstaions(ticket, contactList, agentList).then(function () {
												conver_attachments.forEach(el => attachmentValues.push(el.name))
												conversation_details_to_print.push({
													label: 'Attachments',
													value: (values + attachmentValues)
												});
												prepareFields(conversation_details_to_print, 'conversation_details');

											})
												.then(function () {
													conver_attachments = [], attachmentValues = []
												})
												.catch((e) => {
													notify(e)
												});
											conversation_flag = false;
										}
										conversation_flag = false;
										if (conversation_flag == false) {
											conver_attachments.forEach(el => attachmentValues.push(el.name))
										}

										break;
									case 'ccemail':
										var email = new Array();
										email = ticket.cc_emails;
										if (email.length > 0) {
											conversation_details_to_print.push({
												label: 'CCemail',
												value: email
											});
										}
										break;
									case 'newest':
										newest_flag = true;
										break;
									default:
										if (getValue(index, ticket, ticket_fields) !== null) {
											ticket_details_to_print.push({
												label: getLabel(index, ticket_fields),
												value: getValue(index, ticket, ticket_fields)
											});
										}

										break;
								}
							}
						});
						checkAgent(ticket_details_to_print).then((d) => {
							return checkProduct(d);
						}).then(td => {
							prepareFields(td, 'ticket_details');
							prepareFields(conversation_details_to_print, 'conversation_details');
							resolve(setConverstaions(ticket, contactList, agentList).then(function () {
								conver_attachments = [];
							}).catch((e) => {
								notify(e)
							}));
						}).catch(reject);
					}).catch((e) => {
						notify(e)
					});
				});
			};
			this.getUserNamesForConversations = (conversations, contactList, agentList) => {
				var users = _.reduce(conversations, (prev, curr) => {
					return curr.incoming ? prev.concat(curr.user_id) : prev;
				}, []);
				var agents = _.reduce(conversations, (prev, curr) => {
					return !curr.incoming ? prev.concat(curr.user_id) : prev;
				}, []);
				users = _.unique(users);
				agents = _.unique(agents);
				return new Promise((resolve, reject) => {
					var users_list = [];
					agentList.forEach(agent => {
						agents.forEach(el => {
							if (parseInt(agent.id) === parseInt(el)) {
								users_list.push(agent);
							}
						})
					})
					contactList.forEach(agent => {
						users.forEach(el => {
							if (parseInt(agent.id) === parseInt(el)) {
								users_list.push(agent)
							}
						})
					})
					var user_ids = {};
					_.each(users_list, (v) => {
						if ('contact' in v) {
							user_ids[v.id] = v.contact.name;
						} else {
							user_ids[v.id] = v.name;
						}
					});
					resolve(user_ids);
					reject({ type: "Danger" })
				});
			};
			this.context = new Array();
			this.setConverstaions = (ticket, contactList, agentList) => {
				return new Promise((resolve, reject) => {
					requestApi({
						url: '/api/v2/tickets/' + ticket.id + '/conversations',
						method: 'get'
					}).then(function (d) {
						conversations = JSON.parse(d);
						if (newest_flag == 1) {
							var con = Object.assign([], conversations).reverse();
						}
						else {
							var con = Object.assign([], conversations);
						}

						if (conversations.length == 0) {
							$('.comments_div').hide();
							resolve('done');
						}
						if (private_conversations) {

							for (var i = 0; i < con.length; i++) {
								if (!con[i].private) {
									var attachment1 = con[i].attachments;
									attachment1.forEach(attachment => {
										const index = conver_attachments.findIndex(el => el.id === attachment.id)
										if (index === -1) {
											conver_attachments.push(attachment);
										}
									});

								}
							}
						} else {
							for (var i = 0; i < con.length; i++) {
								var attachment1 = con[i].attachments;
								attachment1.forEach(attachment => {
									const index = conver_attachments.findIndex(el => el.id === attachment.id)
									if (index === -1) {
										conver_attachments.push(attachment);
									}
								});
							}
						}
						getUserNamesForConversations(conversations, contactList, agentList).then(users => {
							var html = '';
							if (private_conversations) {
								con.forEach(each => {
									if (!each.private) {
										var note = each.private ? 'Private Note' : 'Public Note';
										var created_at = new Date(each.created_at).toDateString() + ' ' + new Date(each.created_at).toLocaleTimeString();
										html = html + '<div><div>by ' + '<strong>' + users[each.user_id] + '</strong> on <strong>' + created_at + '</strong> as <strong> ' + note + ' </strong> </div> <div class="description">' + each.body + ' <div> <br> </div> </div> <span class="seperator"></span>';
									}
								})
							} else {
								con.forEach(each => {
									var note = each.private ? 'Private Note' : 'Public Note';
									var created_at = new Date(each.created_at).toDateString() + ' ' + new Date(each.created_at).toLocaleTimeString();
									html = html + '<div><div>by ' + '<strong>' + users[each.user_id] + '</strong> on <strong>' + created_at + '</strong> as <strong> ' + note + ' </strong> </div> <div class="description">' + each.body + ' <div> <br> </div> </div> <span class="seperator"></span> </div>';
								})
							}
							$('.comments').html(html, context);
							resolve('done');
						}).catch(reject);
					}).catch(reject);
				});
			};
			this.prepareFields = function (arr, label) {
				arr.forEach((ar, i) => {
					if (ar.value === null) {
						arr.splice(i, 1)
					}
				})
				if (label === "conversation_details") {
					var a = _.reduce(arr, (prev, curr) => {
						return curr.value === null || curr.value === '' ? prev : prev + '<span id=' + curr.label + '> <b>' + curr.label + '</b> ' + curr.value + ' </span>';
					}, '');
					$('#' + label).html(a);
				} else {
					var count = 0;
					var a = '<div class="divwrapper">';
					arr.forEach(el => {
						if (count % 4 === 0 && count !== 0) {
							a = a + '</div><div class="divwrapper">'
						}
						a = a + '<span id=' + el.label + '> <b>' + el.label + '</b> ' + el.value + ' </span>';
						count++;
					})
					$('#' + label).html(a);
				}

			};
			this.checkProduct = ticket_details_to_print => {
				return new Promise((resolve, reject) => {
					var ag = _.where(ticket_details_to_print, {
						label: "Product"
					});
					if (ag.length > 0 && ag[0].value !== null) {
						requestApi({
							url: '/api/v2/products/' + ag[0].value,
							method: 'get'
						}).then(d => {
							product = JSON.parse(d).name;
							_.each(ticket_details_to_print, (ar, i) => {
								if (ar.label == 'Product') {
									ticket_details_to_print[i].value = product;
								}
							});
							resolve(ticket_details_to_print);
						}).catch(reject);
					} else {
						resolve(ticket_details_to_print);
					}
				});
			};
			this.checkAgent = ticket_details_to_print => {
				return new Promise((resolve, reject) => {
					var ag = _.where(ticket_details_to_print, {
						label: "Agent"
					});

					if (ag.length > 0 && ag[0].value !== null) {
						requestApi({
							url: '/api/v2/agents/' + ag[0].value,
							method: 'get'
						}).then(d => {
							agent = JSON.parse(d).contact.name;
							_.each(ticket_details_to_print, (ar, i) => {
								if (ar.label == 'Agent') {
									ticket_details_to_print[i].value = agent;
								}
							});
							resolve(ticket_details_to_print);
						}).catch(reject);
					} else {
						resolve(ticket_details_to_print);
					}

				});
			};

			this.getLabel = function (key, fields) {
				key = key == "type" ? "ticket_type" : key;
				return _.findWhere(fields, {
					name: key
				}).label;
			};
			this.getChoice = function (key, fields) {
				return _.findWhere(fields, {
					name: key
				}).choices;
			};
			this.getValue = function (key, jsonData, ticket_fields) {
				var value,
					choices;
				switch (key) {
					case 'status':
						choices = getChoice(key, ticket_fields);
						value = choices[jsonData[key]][0];
						break;
					case 'priority':
					case 'source':
						choices = getChoice(key, ticket_fields);
						value = _.invert(choices)[jsonData[key]];
						break;
					case 'tags':

						value = jsonData[key].length == 0 ? null : jsonData[key].join(', ');
						break;

					default:
						value = jsonData[key];
						break;
				}
				if (key.split('_')[0] == 'cf') {
					value = jsonData.custom_fields[key];
				} else {

				}
				return value;
			};
			this.getContactValue = function (key, jsonData) {

				if (key in jsonData) {
					return jsonData[key];
				}
				return null;
			};
			window.notify = function (error) {
				var msg = "";
				if (error.message.toLowerCase().indexOf("null") >= 0) {
					msg = "Please allow Popup on your browser to print ticket";
				} else {
					msg = error.message;
				}
				client.interface.trigger("showNotify", {
					type: "warning",
					title: "Custom print app",
					message: msg
				});
			};
			this.agentPromise = requestApi({
				url: '/api/v2/agents',
				method: 'get'
			})
			this.contactPromise = requestApi({
				url: '/api/v2/contacts',
				method: 'get'
			})


			client.events.on('app.activated',
				function () {
					var pageNumber = 1;
					var allAgentData = []
					function getAgentData(url) {
						return new Promise((resolve, reject) => {
							requestApi({
								url: url,
								method: 'get'
							})
								.then( function (data) {
									data = JSON.parse(data);
									data.forEach(element => {
										allAgentData.push(element)
									});
									if (data.length === 100) {
										pageNumber++;
										 getAgentData(`/api/v2/agents?page=${pageNumber}&per_page=100`)
									}
									resolve(allAgentData)
								}).catch(reject)
						})
					}
					var allContactData = []
					function getContactData(url) {
						 requestApi({
								url: url,
								method: 'get'
							})
								.then( function (data) {
									data = JSON.parse(data);
									data.forEach(element => {
										allContactData.push(element)
									});
									if (data.length === 40) {
										pageNumber++;
										 getContactData(`/api/v2/contacts?page=${pageNumber}&per_page=40`)
									}else{
										console.log("all",allContactData);
										return allContactData;
										
									}
								})
					}
					Promise.all([getContactData(`/api/v2/contacts?page=${pageNumber}&per_page=40`), getAgentData(`/api/v2/agents?page=${pageNumber}&per_page=100`)])
						.then((data) => {
							appActivated(data[0], data[1]);
							console.log("data[0]",data[0]);
							console.log("data[1]",data[1]);
						}).catch(notify)
				});

		}).catch((e) => {
			notify(e)
		});
});
